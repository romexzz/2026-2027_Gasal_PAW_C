
CREATE DATABASE IF NOT EXISTS penjualan CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE penjualan;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS transaksi_detail, pembayaran, transaksi, barang, supplier, pelanggan, `user`;
SET FOREIGN_KEY_CHECKS = 1;


CREATE TABLE pelanggan (
  id            VARCHAR(20)  NOT NULL,
  nama          VARCHAR(100) NOT NULL,
  jenis_kelamin ENUM('L','P') NOT NULL,
  telp          VARCHAR(12),
  alamat        TEXT,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE supplier (
  id     INT(11)      NOT NULL AUTO_INCREMENT,
  nama   VARCHAR(100) NOT NULL,
  telp   VARCHAR(12),
  alamat TEXT,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE barang (
  id          INT(11)      NOT NULL AUTO_INCREMENT,
  kode_barang VARCHAR(10)  NOT NULL,
  nama_barang VARCHAR(100) NOT NULL,
  harga       INT(11)      NOT NULL,
  stok        INT(11)      NOT NULL,
  supplier_id INT(11)      NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_barang_supplier FOREIGN KEY (supplier_id) REFERENCES supplier(id)
) ENGINE=InnoDB;

CREATE TABLE transaksi (
  id               INT(11)     NOT NULL AUTO_INCREMENT,
  waktu_transaksi  DATE        NOT NULL,
  keterangan       TEXT,
  total            INT(11)     NOT NULL,
  pelanggan_id     VARCHAR(20) NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_transaksi_pelanggan FOREIGN KEY (pelanggan_id) REFERENCES pelanggan(id)
) ENGINE=InnoDB;

CREATE TABLE transaksi_detail (
  transaksi_id INT(11) NOT NULL,
  barang_id    INT(11) NOT NULL,
  harga        INT(11) NOT NULL,
  qty          INT(11) NOT NULL,
  PRIMARY KEY (transaksi_id, barang_id),
  CONSTRAINT fk_detail_transaksi FOREIGN KEY (transaksi_id) REFERENCES transaksi(id),
  CONSTRAINT fk_detail_barang    FOREIGN KEY (barang_id)    REFERENCES barang(id)
) ENGINE=InnoDB;

CREATE TABLE pembayaran (
  id           INT(11)  NOT NULL AUTO_INCREMENT,
  waktu_bayar  DATETIME NOT NULL,
  total        INT(11)  NOT NULL,
  metode       ENUM('TUNAI','TRANSFER','EDC') NOT NULL,
  transaksi_id INT(11)  NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_pembayaran_transaksi FOREIGN KEY (transaksi_id) REFERENCES transaksi(id)
) ENGINE=InnoDB;

CREATE TABLE `user` (
  id_user  TINYINT(2)   NOT NULL AUTO_INCREMENT,
  username VARCHAR(30)  NOT NULL,
  password VARCHAR(35)  NOT NULL,
  nama     VARCHAR(50)  NOT NULL,
  alamat   VARCHAR(150),
  hp       VARCHAR(20),
  level    TINYINT(1)   NOT NULL,
  PRIMARY KEY (id_user)
) ENGINE=InnoDB;

-- ---------- DATA MASTER (minimal 10 data/tabel) ----------
INSERT INTO supplier (nama, telp, alamat) VALUES
('PT. Maju Bersama',   '08123456',     'Surabaya'),
('PT. Senang Sekali',  '081515563',    'Bangkalan'),
('PT. Segar Segar',    '0845454663',   'Surabaya'),
('CV. Sumber Rejeki',  '031556677',    'Sumenep'),
('PT. Abadi Jaya',     '081233445566', 'Sidoarjo'),
('CV. Berkah Makmur',  '085711223344', 'Malang'),
('PT. Cahaya Utama',   '082199887766', 'Gresik'),
('UD. Tani Makmur',    '081322334455', 'Pamekasan'),
('PT. Sinar Mulia',    '087855667788', 'Mojokerto'),
('CV. Mitra Sejahtera','081944556677', 'Sampang');

INSERT INTO barang (kode_barang, nama_barang, harga, stok, supplier_id) VALUES
('BRG001', 'Beras 5 Kg',        62000,  50, 1),
('BRG002', 'Minyak Goreng 2 L', 34000,  40, 2),
('BRG003', 'Gula Pasir 1 Kg',   16000,  60, 3),
('BRG004', 'Telur Ayam 1 Kg',   28000,  30, 4),
('BRG005', 'Tepung Terigu 1 Kg',12000,  45, 5),
('BRG006', 'Kopi Bubuk 200 g',  18000,  35, 6),
('BRG007', 'Teh Celup 25 pcs',   9000,  70, 7),
('BRG008', 'Susu UHT 1 L',      18500,  25, 1),
('BRG009', 'Mie Instan',         3500, 200, 2),
('BRG010', 'Sabun Mandi',        4500,  80, 3);

INSERT INTO pelanggan (id, nama, jenis_kelamin, telp, alamat) VALUES
('PLG001', 'Budi Santoso',   'L', '081234567890', 'Surabaya'),
('PLG002', 'Siti Aminah',    'P', '081298765432', 'Bangkalan'),
('PLG003', 'Ahmad Fauzi',    'L', '085612345678', 'Sumenep'),
('PLG004', 'Dewi Lestari',   'P', '082134567890', 'Sidoarjo'),
('PLG005', 'Rizky Pratama',  'L', '087712345678', 'Malang'),
('PLG006', 'Nur Hidayah',    'P', '081345678901', 'Gresik'),
('PLG007', 'Eko Prasetyo',   'L', '085798765432', 'Pamekasan'),
('PLG008', 'Lina Marlina',   'P', '082245678901', 'Mojokerto'),
('PLG009', 'Hendra Gunawan', 'L', '081567890123', 'Sampang'),
('PLG010', 'Rina Wulandari', 'P', '087856789012', 'Surabaya');

INSERT INTO `user` (username, password, nama, alamat, hp, level) VALUES
('admin',   MD5('admin123'),  'Administrator', 'Surabaya',  '081111111111', 1),
('kasir1',  MD5('kasir123'),  'Andi Kasir',    'Sumenep',   '081222222222', 2),
('kasir2',  MD5('kasir123'),  'Sari Kasir',    'Bangkalan', '081333333333', 2),
('gudang1', MD5('gudang123'), 'Joko Gudang',   'Sidoarjo',  '081444444444', 3),
('gudang2', MD5('gudang123'), 'Tono Gudang',   'Malang',    '081555555555', 3),
('owner',   MD5('owner123'),  'Pak Owner',     'Surabaya',  '081666666666', 1),
('kasir3',  MD5('kasir123'),  'Rani Kasir',    'Gresik',    '081777777777', 2),
('kasir4',  MD5('kasir123'),  'Dimas Kasir',   'Pamekasan', '081888888888', 2),
('staff1',  MD5('staff123'),  'Wati Staff',    'Mojokerto', '081999999999', 3),
('staff2',  MD5('staff123'),  'Yudi Staff',    'Sampang',   '081000000000', 3);

-- ---------- DATA TRANSAKSI ----------
INSERT INTO transaksi (waktu_transaksi, keterangan, total, pelanggan_id) VALUES
('2026-10-01', 'Pembelian sembako',   94000,  'PLG001'),
('2026-10-02', 'Pembelian dapur',     80000,  'PLG002'),
('2026-10-03', 'Belanja mingguan',    55000,  'PLG003'),
('2026-10-05', 'Kopi dan susu',       54500,  'PLG004'),
('2026-10-07', 'Mie dan sabun',       44000,  'PLG005'),
('2026-10-09', 'Beras 2 sak',        124000,  'PLG006'),
('2026-10-12', 'Gula dan minyak',    114000,  'PLG007'),
('2026-10-15', 'Teh dan susu',        55000,  'PLG008'),
('2026-10-18', 'Bahan kue',           81500,  'PLG009'),
('2026-10-20', 'Kopi dan sabun',      31500,  'PLG010');

INSERT INTO transaksi_detail (transaksi_id, barang_id, harga, qty) VALUES
(1, 1, 62000, 1), (1, 3, 16000, 2),
(2, 2, 34000, 2), (2, 5, 12000, 1),
(3, 4, 28000, 1), (3, 7,  9000, 3),
(4, 6, 18000, 2), (4, 8, 18500, 1),
(5, 9,  3500,10), (5,10,  4500, 2),
(6, 1, 62000, 2),
(7, 3, 16000, 5), (7, 2, 34000, 1),
(8, 7,  9000, 2), (8, 8, 18500, 2),
(9, 5, 12000, 3), (9, 4, 28000, 1), (9, 9, 3500, 5),
(10,6, 18000, 1), (10,10, 4500, 3);

INSERT INTO pembayaran (waktu_bayar, total, metode, transaksi_id) VALUES
('2026-10-01 09:15:00',  94000, 'TUNAI',    1),
('2026-10-02 10:30:00',  80000, 'TRANSFER', 2),
('2026-10-03 11:05:00',  55000, 'TUNAI',    3),
('2026-10-05 13:20:00',  54500, 'EDC',      4),
('2026-10-07 14:45:00',  44000, 'TUNAI',    5),
('2026-10-09 08:50:00', 124000, 'TRANSFER', 6),
('2026-10-12 16:10:00', 114000, 'EDC',      7),
('2026-10-15 09:40:00',  55000, 'TUNAI',    8),
('2026-10-18 12:25:00',  81500, 'TRANSFER', 9),
('2026-10-20 15:35:00',  31500, 'EDC',     10);
