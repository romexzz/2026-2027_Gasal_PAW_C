<?php
require 'koneksi.php';

// Hanya menerima POST (dikirim dari tombol Hapus setelah klik OK di popup konfirmasi)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$id = (int) ($_POST['id'] ?? 0);

try {
    $stmt = $conn->prepare('DELETE FROM supplier WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    header('Location: index.php?pesan=hapus');
} catch (mysqli_sql_exception $e) {
    // Gagal karena foreign key (supplier masih dipakai di tabel barang)
    header('Location: index.php?pesan=gagal');
}
exit;
