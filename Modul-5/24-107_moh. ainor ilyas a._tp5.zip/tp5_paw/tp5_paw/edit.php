<?php
require 'koneksi.php';

$error = '';
$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

// Ambil data supplier yang akan diedit
$stmt = $conn->prepare('SELECT id, nama, telp, alamat FROM supplier WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$supplier = $stmt->get_result()->fetch_assoc();

if (!$supplier) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama   = trim($_POST['nama']   ?? '');
    $telp   = trim($_POST['telp']   ?? '');
    $alamat = trim($_POST['alamat'] ?? '');

    // tampilkan kembali isian terakhir jika validasi gagal
    $supplier['nama'] = $nama;
    $supplier['telp'] = $telp;
    $supplier['alamat'] = $alamat;

    if ($nama === '') {
        $error = 'Nama supplier wajib diisi.';
    } elseif (!preg_match('/^[0-9]{0,12}$/', $telp)) {
        $error = 'Telp harus berupa angka, maksimal 12 digit.';
    } else {
        $stmt = $conn->prepare('UPDATE supplier SET nama = ?, telp = ?, alamat = ? WHERE id = ?');
        $stmt->bind_param('sssi', $nama, $telp, $alamat, $id);
        $stmt->execute();
        header('Location: index.php?pesan=update');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Master Supplier</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="header"><h1>Edit Data Master Supplier</h1></div>

    <?php if ($error): ?>
        <div class="alert alert-gagal"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" class="form">
        <input type="hidden" name="id" value="<?= $supplier['id'] ?>">
        <div class="baris">
            <label for="nama">Nama</label>
            <input type="text" id="nama" name="nama" class="lebar"
                   value="<?= htmlspecialchars($supplier['nama']) ?>" required>
        </div>
        <div class="baris">
            <label for="telp">Telp</label>
            <input type="text" id="telp" name="telp" maxlength="12"
                   value="<?= htmlspecialchars($supplier['telp']) ?>">
        </div>
        <div class="baris">
            <label for="alamat">Alamat</label>
            <input type="text" id="alamat" name="alamat"
                   value="<?= htmlspecialchars($supplier['alamat']) ?>">
        </div>
        <div class="baris tombol">
            <button type="submit" class="btn btn-hijau">Update</button>
            <a href="index.php" class="btn btn-merah">Batal</a>
        </div>
    </form>
</div>
</body>
</html>
