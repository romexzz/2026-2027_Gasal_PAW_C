<?php
require 'koneksi.php';

$error = '';
$nama = $telp = $alamat = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama   = trim($_POST['nama']   ?? '');
    $telp   = trim($_POST['telp']   ?? '');
    $alamat = trim($_POST['alamat'] ?? '');

    if ($nama === '') {
        $error = 'Nama supplier wajib diisi.';
    } elseif (!preg_match('/^[0-9]{0,12}$/', $telp)) {
        $error = 'Telp harus berupa angka, maksimal 12 digit.';
    } else {
        $stmt = $conn->prepare('INSERT INTO supplier (nama, telp, alamat) VALUES (?, ?, ?)');
        $stmt->bind_param('sss', $nama, $telp, $alamat);
        $stmt->execute();
        header('Location: index.php?pesan=tambah');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Data Master Supplier Baru</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="header"><h1>Tambah Data Master Supplier Baru</h1></div>

    <?php if ($error): ?>
        <div class="alert alert-gagal"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" class="form">
        <div class="baris">
            <label for="nama">Nama</label>
            <input type="text" id="nama" name="nama" class="lebar" placeholder="Nama"
                   value="<?= htmlspecialchars($nama) ?>" required>
        </div>
        <div class="baris">
            <label for="telp">Telp</label>
            <input type="text" id="telp" name="telp" placeholder="telp" maxlength="12"
                   value="<?= htmlspecialchars($telp) ?>">
        </div>
        <div class="baris">
            <label for="alamat">Alamat</label>
            <input type="text" id="alamat" name="alamat" placeholder="alamat"
                   value="<?= htmlspecialchars($alamat) ?>">
        </div>
        <div class="baris tombol">
            <button type="submit" class="btn btn-hijau">Simpan</button>
            <a href="index.php" class="btn btn-merah">Batal</a>
        </div>
    </form>
</div>
</body>
</html>
