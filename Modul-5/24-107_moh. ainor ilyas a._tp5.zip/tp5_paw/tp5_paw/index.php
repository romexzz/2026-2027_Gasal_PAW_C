<?php
require 'koneksi.php';

$pesan_list = [
    'tambah' => ['sukses', 'Data supplier berhasil ditambahkan.'],
    'update' => ['sukses', 'Data supplier berhasil diperbarui.'],
    'hapus'  => ['sukses', 'Data supplier berhasil dihapus.'],
    'gagal'  => ['gagal',  'Supplier tidak bisa dihapus karena masih dipakai oleh data barang.'],
];
$pesan = $pesan_list[$_GET['pesan'] ?? ''] ?? null;

$hasil = $conn->query('SELECT id, nama, telp, alamat FROM supplier ORDER BY id');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Master Supplier</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Data Master Supplier</h1>
        <a href="tambah.php" class="btn btn-hijau">Tambah Data</a>
    </div>

    <?php if ($pesan): ?>
        <div class="alert alert-<?= $pesan[0] ?>"><?= $pesan[1] ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th width="50">No</th>
                <th>Nama</th>
                <th>Telp</th>
                <th>Alamat</th>
                <th width="150">Tindakan</th>
            </tr>
        </thead>
        <tbody>
        <?php $no = 1; while ($row = $hasil->fetch_assoc()): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= htmlspecialchars($row['telp']) ?></td>
                <td><?= htmlspecialchars($row['alamat']) ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-oranye">Edit</a>
                    <form action="hapus.php" method="post" class="inline"
                          onsubmit="return confirm('Anda yakin akan menghapus supplier ini?');">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <button type="submit" class="btn btn-merah">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
        <?php if ($no === 1): ?>
            <tr><td colspan="5" align="center">Belum ada data supplier.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
