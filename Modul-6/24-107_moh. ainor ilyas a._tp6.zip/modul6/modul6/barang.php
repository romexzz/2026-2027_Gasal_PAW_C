<?php
// Daftar barang: tambah, edit, hapus (dengan pengecekan data terkait)
require 'koneksi.php';
$judul = "Data Barang";
require 'header.php';

$data = $koneksi->query(
    "SELECT b.id, b.kode_barang, b.nama_barang, b.harga, b.stok, s.nama AS supplier
     FROM barang b JOIN supplier s ON s.id = b.supplier_id
     ORDER BY b.kode_barang"
);
?>
<h2>Data Barang</h2>
<p><a href="form_barang.php"><button type="button">+ Tambah Barang</button></a></p>
<table>
  <tr><th>Kode</th><th>Nama Barang</th><th class="kanan">Harga</th><th class="kanan">Stok</th><th>Supplier</th><th>Aksi</th></tr>
  <?php while ($r = $data->fetch_assoc()): ?>
  <tr>
    <td><?= e($r['kode_barang']) ?></td>
    <td><?= e($r['nama_barang']) ?></td>
    <td class="kanan"><?= rupiah($r['harga']) ?></td>
    <td class="kanan"><?= $r['stok'] ?></td>
    <td><?= e($r['supplier']) ?></td>
    <td style="white-space:nowrap">
      <a href="form_barang.php?id=<?= $r['id'] ?>"><button type="button">Edit</button></a>
      <form method="post" action="hapus_barang.php" style="display:inline"
            onsubmit="return confirm('Yakin hapus barang <?= e($r['nama_barang']) ?>?');">
        <input type="hidden" name="id" value="<?= $r['id'] ?>">
        <button type="submit">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endwhile; ?>
</table>
</body>
</html>