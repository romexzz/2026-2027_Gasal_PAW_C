<?php
// Hapus barang hanya jika belum dipakai di transaksi_detail
require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: barang.php");
    exit;
}

$id = (int)($_POST['id'] ?? 0);

// Ambil nama barang untuk pesan notifikasi
$stmt = $koneksi->prepare("SELECT nama_barang FROM barang WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$barang = $stmt->get_result()->fetch_assoc();

if (!$barang) {
    set_pesan('err', 'Barang tidak ditemukan.');
    header("Location: barang.php");
    exit;
}

// Cek apakah barang sudah dipakai pada transaksi_detail
$stmt = $koneksi->prepare("SELECT COUNT(*) AS jumlah FROM transaksi_detail WHERE barang_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$jumlah = (int)$stmt->get_result()->fetch_assoc()['jumlah'];

if ($jumlah > 0) {
    set_pesan('err', "Barang \"{$barang['nama_barang']}\" tidak dapat dihapus karena masih digunakan pada $jumlah transaksi.");
} else {
    $stmt = $koneksi->prepare("DELETE FROM barang WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    set_pesan('ok', "Barang \"{$barang['nama_barang']}\" berhasil dihapus.");
}

header("Location: barang.php");
exit;
