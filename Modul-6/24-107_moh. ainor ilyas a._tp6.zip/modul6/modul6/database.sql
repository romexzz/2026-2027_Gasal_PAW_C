-- Modul 6 PAW: Master Detil (database penjualan)
CREATE DATABASE IF NOT EXISTS penjualan CHARACTER SET utf8mb4;
USE penjualan;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS pembayaran, transaksi_detail, transaksi, barang, supplier, pelanggan, user;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE supplier (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  telp VARCHAR(12),
  alamat TEXT
) ENGINE=InnoDB;

CREATE TABLE pelanggan (
  id VARCHAR(20) PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  jenis_kelamin ENUM('L','P') NOT NULL,
  telp VARCHAR(12),
  alamat TEXT
) ENGINE=InnoDB;

CREATE TABLE barang (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode_barang VARCHAR(10) NOT NULL UNIQUE,
  nama_barang VARCHAR(100) NOT NULL,
  harga INT NOT NULL,
  stok INT NOT NULL DEFAULT 0,
  supplier_id INT NOT NULL,
  CONSTRAINT fk_barang_supplier FOREIGN KEY (supplier_id)
    REFERENCES supplier(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE transaksi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  waktu_transaksi DATE NOT NULL,
  keterangan TEXT,
  total INT NOT NULL DEFAULT 0,
  pelanggan_id VARCHAR(20) NOT NULL,
  CONSTRAINT fk_transaksi_pelanggan FOREIGN KEY (pelanggan_id)
    REFERENCES pelanggan(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE transaksi_detail (
  transaksi_id INT NOT NULL,
  barang_id INT NOT NULL,
  harga INT NOT NULL,
  qty INT NOT NULL,
  PRIMARY KEY (transaksi_id, barang_id),
  CONSTRAINT fk_detail_transaksi FOREIGN KEY (transaksi_id)
    REFERENCES transaksi(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_detail_barang FOREIGN KEY (barang_id)
    REFERENCES barang(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE pembayaran (
  id INT AUTO_INCREMENT PRIMARY KEY,
  waktu_bayar DATETIME NOT NULL,
  total INT NOT NULL,
  metode ENUM('TUNAI','TRANSFER','EDC') NOT NULL,
  transaksi_id INT NOT NULL,
  CONSTRAINT fk_bayar_transaksi FOREIGN KEY (transaksi_id)
    REFERENCES transaksi(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE user (
  id_user TINYINT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(30) NOT NULL UNIQUE,
  password VARCHAR(35) NOT NULL,
  nama VARCHAR(50) NOT NULL,
  alamat VARCHAR(150),
  hp VARCHAR(20),
  level TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- ===== DATA MASTER (masing-masing minimal 5) =====
INSERT INTO supplier (nama, telp, alamat) VALUES
('PT Sumber Makmur',  '031555101', 'Jl. Raya Surabaya No. 10'),
('CV Maju Jaya',      '031555102', 'Jl. Pahlawan No. 21, Sidoarjo'),
('UD Berkah Abadi',   '031555103', 'Jl. Diponegoro No. 5, Malang'),
('PT Nusantara Niaga','031555104', 'Jl. Gatot Subroto No. 88, Kediri'),
('CV Sinar Terang',   '031555105', 'Jl. Sudirman No. 12, Madura'),
('UD Tani Sejahtera', '031555106', 'Jl. Merdeka No. 3, Pamekasan');

INSERT INTO pelanggan (id, nama, jenis_kelamin, telp, alamat) VALUES
('P001','Budi Santoso','L','081200000001','Jl. Mawar No. 1, Bangkalan'),
('P002','Siti Aminah','P','081200000002','Jl. Melati No. 2, Bangkalan'),
('P003','Ahmad Fauzi','L','081200000003','Jl. Kenanga No. 3, Sampang'),
('P004','Dewi Lestari','P','081200000004','Jl. Anggrek No. 4, Pamekasan'),
('P005','Rizki Ramadhan','L','081200000005','Jl. Dahlia No. 5, Sumenep'),
('P006','Nur Hasanah','P','081200000006','Jl. Teratai No. 6, Sumenep');

INSERT INTO barang (kode_barang, nama_barang, harga, stok, supplier_id) VALUES
('BRG001','Beras 5 kg',        65000, 100, 1),
('BRG002','Minyak Goreng 2 L', 38000,  80, 1),
('BRG003','Gula Pasir 1 kg',   17000, 120, 2),
('BRG004','Telur Ayam 1 kg',   29000,  60, 3),
('BRG005','Tepung Terigu 1 kg',12000,  90, 4),
('BRG006','Kopi Bubuk 200 g',  22000,  70, 5),
('BRG007','Teh Celup 25 pcs',  9000,  150, 5),
('BRG008','Susu UHT 1 L',      18000,  75, 6);

INSERT INTO user (username, password, nama, alamat, hp, level) VALUES
('admin',  MD5('admin123'),  'Administrator', 'Bangkalan', '081300000001', 1),
('kasir1', MD5('kasir123'),  'Kasir Satu',    'Bangkalan', '081300000002', 2),
('kasir2', MD5('kasir123'),  'Kasir Dua',     'Sampang',   '081300000003', 2),
('gudang', MD5('gudang123'), 'Staf Gudang',   'Sampang',   '081300000004', 3),
('owner',  MD5('owner123'),  'Pemilik Toko',  'Pamekasan', '081300000005', 1);

-- ===== DATA TRANSAKSI (10 transaksi) =====
INSERT INTO transaksi (waktu_transaksi, keterangan, total, pelanggan_id) VALUES
('2026-10-01','Belanja bulanan',0,'P001'),
('2026-10-02','Belanja dapur',0,'P002'),
('2026-10-03','Pembelian grosir',0,'P003'),
('2026-10-05','Belanja mingguan',0,'P004'),
('2026-10-06','Kebutuhan warung',0,'P005'),
('2026-10-08','Belanja bulanan',0,'P006'),
('2026-10-10','Pembelian kecil',0,'P001'),
('2026-10-12','Belanja dapur',0,'P002'),
('2026-10-14','Pembelian grosir',0,'P003'),
('2026-10-15','Belanja mingguan',0,'P004');

INSERT INTO transaksi_detail (transaksi_id, barang_id, harga, qty) VALUES
(1,1,65000,2),(1,2,38000,1),
(2,3,17000,3),(2,4,29000,1),
(3,1,65000,5),(3,5,12000,10),(3,3,17000,4),
(4,6,22000,2),(4,7,9000,3),
(5,2,38000,6),(5,8,18000,6),
(6,1,65000,1),(6,4,29000,2),(6,6,22000,1),
(7,7,9000,5),
(8,5,12000,4),(8,8,18000,2),
(9,2,38000,10),(9,3,17000,10),
(10,4,29000,3),(10,6,22000,2);

-- Hitung total transaksi dari detail
UPDATE transaksi t
SET total = (SELECT COALESCE(SUM(d.harga*d.qty),0)
             FROM transaksi_detail d WHERE d.transaksi_id = t.id);

INSERT INTO pembayaran (waktu_bayar, total, metode, transaksi_id)
SELECT CONCAT(waktu_transaksi,' 10:00:00'), total,
       ELT(1+MOD(id,3),'TUNAI','TRANSFER','EDC'), id
FROM transaksi;
