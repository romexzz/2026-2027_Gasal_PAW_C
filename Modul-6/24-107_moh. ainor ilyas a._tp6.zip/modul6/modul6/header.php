<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title><?= e($judul ?? 'Penjualan') ?></title>
<style>
  body { font-family: Arial, sans-serif; margin: 24px; color: #222; }
  nav a { margin-right: 14px; text-decoration: none; color: #0b5ed7; font-weight: bold; }
  table { border-collapse: collapse; width: 100%; margin: 12px 0; }
  th, td { border: 1px solid #bbb; padding: 6px 10px; text-align: left; }
  th { background: #f0f0f0; }
  .box { border: 1px solid #ccc; padding: 12px 16px; margin: 14px 0; border-radius: 6px; }
  .ok  { background: #d1e7dd; padding: 10px; border-radius: 6px; }
  .err { background: #f8d7da; padding: 10px; border-radius: 6px; }
  .kanan { text-align: right; }
  input, select, button { padding: 6px; margin: 4px 0; }
</style>
</head>
<body>
<nav>
  <a href="transaksi.php">Transaksi</a>
  <a href="barang.php">Barang</a>
</nav>
<hr>
<?php
if (!empty($_SESSION['pesan'])) {
    $p = $_SESSION['pesan'];
    echo '<p class="' . ($p['tipe'] === 'ok' ? 'ok' : 'err') . '">' . e($p['isi']) . '</p>';
    unset($_SESSION['pesan']);
}
