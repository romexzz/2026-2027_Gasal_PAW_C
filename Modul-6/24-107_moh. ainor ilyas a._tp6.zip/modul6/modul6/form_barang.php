formbarang.php
<?php
// Form tambah & edit barang (satu file untuk dua mode)
require 'koneksi.php';

$id   = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$edit = $id > 0;

// Nilai awal form
$barang = ['kode_barang' => '', 'nama_barang' => '', 'harga' => '', 'stok' => '', 'supplier_id' => ''];

if ($edit) {
    $stmt = $koneksi->prepare("SELECT * FROM barang WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();
    if (!$data) {
        set_pesan('err', 'Barang tidak ditemukan.');
        header("Location: barang.php");
        exit;
    }
    $barang = $data;
}

// ---- Proses simpan ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode        = strtoupper(trim($_POST['kode_barang'] ?? ''));
    $nama        = trim($_POST['nama_barang'] ?? '');
    $harga       = (int)($_POST['harga'] ?? 0);
    $stok        = (int)($_POST['stok'] ?? 0);
    $supplier_id = (int)($_POST['supplier_id'] ?? 0);

    $barang = ['kode_barang' => $kode, 'nama_barang' => $nama, 'harga' => $harga,
               'stok' => $stok, 'supplier_id' => $supplier_id];

    $error = '';
    if ($kode === '' || $nama === '' || $supplier_id <= 0) {
        $error = 'Kode, nama barang, dan supplier wajib diisi.';
    } elseif (strlen($kode) > 10) {
        $error = 'Kode barang maksimal 10 karakter.';
    } elseif ($harga <= 0) {
        $error = 'Harga harus lebih dari 0.';
    } elseif ($stok < 0) {
        $error = 'Stok tidak boleh negatif.';
    } else {
        // Kode barang harus unik (abaikan barang yang sedang diedit)
        $cek = $koneksi->prepare("SELECT 1 FROM barang WHERE kode_barang = ? AND id <> ?");
        $cek->bind_param("si", $kode, $id);
        $cek->execute();
        if ($cek->get_result()->num_rows > 0) {
            $error = "Kode barang $kode sudah digunakan.";
        }
    }

    if ($error === '') {
        if ($edit) {
            $stmt = $koneksi->prepare(
                "UPDATE barang SET kode_barang=?, nama_barang=?, harga=?, stok=?, supplier_id=? WHERE id=?"
            );
            $stmt->bind_param("ssiiii", $kode, $nama, $harga, $stok, $supplier_id, $id);
            $stmt->execute();
            set_pesan('ok', "Barang \"$nama\" berhasil diperbarui.");
        } else {
            $stmt = $koneksi->prepare(
                "INSERT INTO barang (kode_barang, nama_barang, harga, stok, supplier_id) VALUES (?, ?, ?, ?, ?)"
            );
            $stmt->bind_param("ssiii", $kode, $nama, $harga, $stok, $supplier_id);
            $stmt->execute();
            set_pesan('ok', "Barang \"$nama\" berhasil ditambahkan.");
        }
        header("Location: barang.php");
        exit;
    }
    set_pesan('err', $error);
}

$supplier = $koneksi->query("SELECT id, nama FROM supplier ORDER BY nama");

$judul = $edit ? "Edit Barang" : "Tambah Barang";
require 'header.php';
?>
<h2><?= $judul ?></h2>
<form method="post" class="box">
  <?php if ($edit): ?><input type="hidden" name="id" value="<?= $id ?>"><?php endif; ?>
  <label>Kode Barang<br>
    <input type="text" name="kode_barang" maxlength="10" value="<?= e($barang['kode_barang']) ?>" required>
  </label><br>
  <label>Nama Barang<br>
    <input type="text" name="nama_barang" size="40" maxlength="100" value="<?= e($barang['nama_barang']) ?>" required>
  </label><br>
  <label>Harga (Rp)<br>
    <input type="number" name="harga" min="1" value="<?= e($barang['harga']) ?>" required>
  </label><br>
  <label>Stok<br>
    <input type="number" name="stok" min="0" value="<?= e($barang['stok']) ?>" required>
  </label><br>
  <label>Supplier<br>
    <select name="supplier_id" required>
      <option value="">-- Pilih supplier --</option>
      <?php while ($s = $supplier->fetch_assoc()): ?>
        <option value="<?= $s['id'] ?>" <?= (int)$barang['supplier_id'] === (int)$s['id'] ? 'selected' : '' ?>>
          <?= e($s['nama']) ?>
        </option>
      <?php endwhile; ?>
    </select>
  </label><br>
  <button type="submit"><?= $edit ? 'Simpan Perubahan' : 'Simpan' ?></button>
  <a href="barang.php">Batal</a>
</form>
</body>
</html>