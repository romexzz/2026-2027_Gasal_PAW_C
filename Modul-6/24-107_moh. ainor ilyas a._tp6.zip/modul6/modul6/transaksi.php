<?php
// Daftar transaksi (master) + form tambah transaksi
require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal      = $_POST['waktu_transaksi'] ?? '';
    $pelanggan_id = $_POST['pelanggan_id'] ?? '';
    $keterangan   = trim($_POST['keterangan'] ?? '');

    if ($tanggal === '' || $pelanggan_id === '') {
        set_pesan('err', 'Tanggal dan pelanggan wajib diisi.');
    } else {
        $stmt = $koneksi->prepare(
            "INSERT INTO transaksi (waktu_transaksi, keterangan, total, pelanggan_id) VALUES (?, ?, 0, ?)"
        );
        $stmt->bind_param("sss", $tanggal, $keterangan, $pelanggan_id);
        $stmt->execute();
        header("Location: transaksi_detail.php?id=" . $koneksi->insert_id);
        exit;
    }
    header("Location: transaksi.php");
    exit;
}

$judul = "Data Transaksi";
require 'header.php';

$pelanggan = $koneksi->query("SELECT id, nama FROM pelanggan ORDER BY nama");
$data = $koneksi->query(
    "SELECT t.id, t.waktu_transaksi, t.keterangan, t.total, p.nama AS pelanggan
     FROM transaksi t JOIN pelanggan p ON p.id = t.pelanggan_id
     ORDER BY t.id DESC"
);
?>
<h2>Tambah Transaksi (Master)</h2>
<form method="post" class="box">
  <label>Tanggal<br><input type="date" name="waktu_transaksi" value="<?= date('Y-m-d') ?>" required></label><br>
  <label>Pelanggan<br>
    <select name="pelanggan_id" required>
      <option value="">-- Pilih pelanggan --</option>
      <?php while ($r = $pelanggan->fetch_assoc()): ?>
        <option value="<?= e($r['id']) ?>"><?= e($r['nama']) ?></option>
      <?php endwhile; ?>
    </select>
  </label><br>
  <label>Keterangan<br><input type="text" name="keterangan" size="40"></label><br>
  <button type="submit">Simpan &amp; Isi Detail</button>
</form>

<h2>Daftar Transaksi</h2>
<table>
  <tr><th>ID</th><th>Tanggal</th><th>Pelanggan</th><th>Keterangan</th><th class="kanan">Total</th><th>Aksi</th></tr>
  <?php while ($r = $data->fetch_assoc()): ?>
  <tr>
    <td><?= $r['id'] ?></td>
    <td><?= e($r['waktu_transaksi']) ?></td>
    <td><?= e($r['pelanggan']) ?></td>
    <td><?= e($r['keterangan']) ?></td>
    <td class="kanan"><?= rupiah($r['total']) ?></td>
    <td><a href="transaksi_detail.php?id=<?= $r['id'] ?>">Lihat / Isi Detail</a></td>
  </tr>
  <?php endwhile; ?>
</table>
</body>
</html>
