<?php
// Halaman master-detail: master = transaksi, detail = transaksi_detail
require 'koneksi.php';

$id = (int)($_GET['id'] ?? 0);

// ---- Ambil data master ----
$stmt = $koneksi->prepare(
    "SELECT t.id, t.waktu_transaksi, t.keterangan, t.total, p.nama AS pelanggan
     FROM transaksi t JOIN pelanggan p ON p.id = t.pelanggan_id
     WHERE t.id = ?"
);
$stmt->bind_param("i", $id);
$stmt->execute();
$master = $stmt->get_result()->fetch_assoc();

if (!$master) {
    set_pesan('err', 'Transaksi tidak ditemukan.');
    header("Location: transaksi.php");
    exit;
}

// ---- Proses simpan detail ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $barang_id = (int)($_POST['barang_id'] ?? 0);
    $qty       = (int)($_POST['qty'] ?? 0);

    if ($barang_id <= 0 || $qty <= 0) {
        set_pesan('err', 'Pilih barang dan isi qty minimal 1.');
        header("Location: transaksi_detail.php?id=$id");
        exit;
    }

    try {
        $koneksi->begin_transaction();

        // Cegah barang yang sama diinput dua kali pada transaksi yang sama
        $cek = $koneksi->prepare("SELECT 1 FROM transaksi_detail WHERE transaksi_id = ? AND barang_id = ?");
        $cek->bind_param("ii", $id, $barang_id);
        $cek->execute();
        if ($cek->get_result()->num_rows > 0) {
            throw new Exception("Barang tersebut sudah ada pada transaksi ini.");
        }

        // Harga diambil dari tabel barang (bukan dari input pengguna)
        $h = $koneksi->prepare("SELECT harga FROM barang WHERE id = ?");
        $h->bind_param("i", $barang_id);
        $h->execute();
        $brg = $h->get_result()->fetch_assoc();
        if (!$brg) {
            throw new Exception("Barang tidak ditemukan.");
        }

        $ins = $koneksi->prepare(
            "INSERT INTO transaksi_detail (transaksi_id, barang_id, harga, qty) VALUES (?, ?, ?, ?)"
        );
        $ins->bind_param("iiii", $id, $barang_id, $brg['harga'], $qty);
        $ins->execute();

        // Hitung ulang total transaksi = SUM(harga * qty) seluruh detail
        $upd = $koneksi->prepare(
            "UPDATE transaksi
             SET total = (SELECT COALESCE(SUM(harga * qty), 0)
                          FROM transaksi_detail WHERE transaksi_id = ?)
             WHERE id = ?"
        );
        $upd->bind_param("ii", $id, $id);
        $upd->execute();

        $koneksi->commit();
        set_pesan('ok', 'Detail transaksi disimpan dan total diperbarui.');
    } catch (Exception $ex) {
        $koneksi->rollback();
        set_pesan('err', $ex->getMessage());
    }
    header("Location: transaksi_detail.php?id=$id");
    exit;
}

$judul = "Detail Transaksi #" . $id;
require 'header.php';

// ---- Detail yang sudah ada ----
$stmt = $koneksi->prepare(
    "SELECT b.kode_barang, b.nama_barang, d.harga, d.qty, (d.harga * d.qty) AS subtotal
     FROM transaksi_detail d JOIN barang b ON b.id = d.barang_id
     WHERE d.transaksi_id = ?
     ORDER BY b.nama_barang"
);
$stmt->bind_param("i", $id);
$stmt->execute();
$detail = $stmt->get_result();

// ---- Dropdown: hanya barang yang BELUM dipakai di transaksi ini ----
$stmt = $koneksi->prepare(
    "SELECT id, kode_barang, nama_barang, harga
     FROM barang
     WHERE id NOT IN (SELECT barang_id FROM transaksi_detail WHERE transaksi_id = ?)
     ORDER BY nama_barang"
);
$stmt->bind_param("i", $id);
$stmt->execute();
$pilihan = $stmt->get_result();
?>
<h2>Master: Transaksi #<?= $master['id'] ?></h2>
<table>
  <tr><th width="160">Tanggal</th><td><?= e($master['waktu_transaksi']) ?></td></tr>
  <tr><th>Pelanggan</th><td><?= e($master['pelanggan']) ?></td></tr>
  <tr><th>Keterangan</th><td><?= e($master['keterangan']) ?></td></tr>
  <tr><th>Total</th><td><strong><?= rupiah($master['total']) ?></strong></td></tr>
</table>

<h2>Detail Transaksi</h2>
<table>
  <tr><th>Kode</th><th>Barang</th><th class="kanan">Harga</th><th class="kanan">Qty</th><th class="kanan">Subtotal</th></tr>
  <?php if ($detail->num_rows === 0): ?>
    <tr><td colspan="5">Belum ada detail.</td></tr>
  <?php endif; ?>
  <?php while ($r = $detail->fetch_assoc()): ?>
  <tr>
    <td><?= e($r['kode_barang']) ?></td>
    <td><?= e($r['nama_barang']) ?></td>
    <td class="kanan"><?= rupiah($r['harga']) ?></td>
    <td class="kanan"><?= $r['qty'] ?></td>
    <td class="kanan"><?= rupiah($r['subtotal']) ?></td>
  </tr>
  <?php endwhile; ?>
</table>

<h3>Tambah Detail</h3>
<?php if ($pilihan->num_rows === 0): ?>
  <p>Semua barang sudah dimasukkan ke transaksi ini.</p>
<?php else: ?>
<form method="post" class="box">
  <label>Barang<br>
    <select name="barang_id" required>
      <option value="">-- Pilih barang --</option>
      <?php while ($b = $pilihan->fetch_assoc()): ?>
        <option value="<?= $b['id'] ?>">
          <?= e($b['kode_barang'] . ' - ' . $b['nama_barang'] . ' (' . rupiah($b['harga']) . ')') ?>
        </option>
      <?php endwhile; ?>
    </select>
  </label><br>
  <label>Qty<br><input type="number" name="qty" min="1" value="1" required></label><br>
  <button type="submit">Simpan Detail</button>
</form>
<?php endif; ?>

<p><a href="transaksi.php">&laquo; Kembali ke daftar transaksi</a></p>
</body>
</html>
