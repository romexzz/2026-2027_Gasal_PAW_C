<?php
// Koneksi database + helper umum
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
session_start();

try {
    $koneksi = new mysqli("localhost", "root", "", "penjualan");
    $koneksi->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

function e($teks) {
    return htmlspecialchars((string)$teks, ENT_QUOTES, 'UTF-8');
}

function rupiah($angka) {
    return "Rp " . number_format((int)$angka, 0, ',', '.');
}

function set_pesan($tipe, $isi) {
    $_SESSION['pesan'] = ['tipe' => $tipe, 'isi' => $isi];
}
