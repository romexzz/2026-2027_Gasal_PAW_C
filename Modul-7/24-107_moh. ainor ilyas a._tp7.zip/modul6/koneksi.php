<?php
// Koneksi database + helper umum
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
session_start();

try {
    $koneksi = new mysqli("localhost", "root", "", "penjualan");
    $koneksi->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

function e($teks) {
    return htmlspecialchars((string)$teks, ENT_QUOTES, 'UTF-8');
}

function rupiah($angka) {
    return "Rp " . number_format((int)$angka, 0, ',', '.');
}

function set_pesan($tipe, $isi) {
    $_SESSION['pesan'] = ['tipe' => $tipe, 'isi' => $isi];
}

// ===== Helper Modul 7 (Reporting) =====

// Validasi format tanggal Y-m-d
function valid_tanggal($tgl) {
    $d = DateTime::createFromFormat('Y-m-d', (string)$tgl);
    return $d && $d->format('Y-m-d') === $tgl;
}

// Ambil data laporan penjualan pada rentang tanggal tertentu:
// rekap total pendapatan per hari, jumlah pelanggan unik, dan total pendapatan keseluruhan.
function ambil_laporan($koneksi, $mulai, $selesai) {
    $hasil = ['rekap' => [], 'pelanggan' => 0, 'pendapatan' => 0];

    // Agregasi: SUM(total) per hari dengan GROUP BY DATE(waktu_transaksi)
    $stmt = $koneksi->prepare(
        "SELECT DATE(waktu_transaksi) AS tgl, SUM(total) AS total_harian
         FROM transaksi
         WHERE DATE(waktu_transaksi) BETWEEN ? AND ?
         GROUP BY DATE(waktu_transaksi)
         ORDER BY tgl ASC"
    );
    $stmt->bind_param("ss", $mulai, $selesai);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($r = $res->fetch_assoc()) {
        $hasil['rekap'][] = $r;
        $hasil['pendapatan'] += $r['total_harian'];
    }
    $stmt->close();

    // Jumlah pelanggan unik: COUNT(DISTINCT pelanggan_id)
    $stmt2 = $koneksi->prepare(
        "SELECT COUNT(DISTINCT pelanggan_id) AS jml
         FROM transaksi
         WHERE DATE(waktu_transaksi) BETWEEN ? AND ?"
    );
    $stmt2->bind_param("ss", $mulai, $selesai);
    $stmt2->execute();
    $row = $stmt2->get_result()->fetch_assoc();
    $hasil['pelanggan'] = (int)($row['jml'] ?? 0);
    $stmt2->close();

    return $hasil;
}
