<?php
require 'koneksi.php';

$mulai   = $_GET['mulai']   ?? '';
$selesai = $_GET['selesai'] ?? '';

if (!valid_tanggal($mulai) || !valid_tanggal($selesai) || $mulai > $selesai) {
    die("Rentang tanggal tidak valid.");
}

$lap = ambil_laporan($koneksi, $mulai, $selesai);

// Header HTTP agar browser mengunduh file Excel
$filename = "Laporan_Penjualan_{$mulai}_sd_{$selesai}.xls";
header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");
?>
<html>
<head><meta charset="UTF-8"></head>
<body>
<h3>Laporan Penjualan</h3>
<p>Periode: <?= date('d-m-Y', strtotime($mulai)) ?> s/d <?= date('d-m-Y', strtotime($selesai)) ?></p>
<table border="1">
    <tr>
        <th>No</th>
        <th>Total Pendapatan</th>
        <th>Tanggal Transaksi</th>
    </tr>
    <?php $no = 1; foreach ($lap['rekap'] as $row): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= (float)$row['total_harian'] ?></td>
        <td><?= date('d-m-Y', strtotime($row['tgl'])) ?></td>
    </tr>
    <?php endforeach; ?>
    <tr>
        <td colspan="2"><b>Jumlah Pelanggan Unik</b></td>
        <td><b><?= $lap['pelanggan'] ?> Orang</b></td>
    </tr>
    <tr>
        <td colspan="2"><b>Total Pendapatan Keseluruhan</b></td>
        <td><b><?= (float)$lap['pendapatan'] ?></b></td>
    </tr>
</table>
</body>
</html>
