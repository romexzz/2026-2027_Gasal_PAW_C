<?php
// Modul 7 - Reporting: laporan penjualan + grafik (Chart.js)
require 'koneksi.php';

$mulai   = $_GET['mulai']   ?? '';
$selesai = $_GET['selesai'] ?? '';
$error   = '';
$tampil  = false;
$labels = $data_total = $rekap = [];
$total_pendapatan = $total_pelanggan = 0;

if ($mulai !== '' || $selesai !== '') {
    if (!valid_tanggal($mulai) || !valid_tanggal($selesai)) {
        $error = "Format tanggal tidak valid.";
    } elseif ($mulai > $selesai) {
        $error = "Tanggal mulai tidak boleh lebih besar dari tanggal selesai.";
    } else {
        $tampil = true;
        $lap = ambil_laporan($koneksi, $mulai, $selesai);
        $rekap            = $lap['rekap'];
        $total_pelanggan  = $lap['pelanggan'];
        $total_pendapatan = $lap['pendapatan'];
        foreach ($rekap as $r) {
            $labels[]     = $r['tgl'];
            $data_total[] = (float)$r['total_harian'];
        }
    }
}

function tgl_id($t) { return date('d-m-Y', strtotime($t)); }

$judul = "Laporan Penjualan dan Grafik";
$head_tambahan = <<<HTML
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
  .chart-box { width: 100%; max-width: 800px; height: 340px; }
  .card { display: flex; gap: 16px; margin-top: 16px; }
  .card div { flex: 1; border: 1px solid #000; padding: 12px; border-radius: 6px; }
  .card small { display: block; color: #555; }
  .card strong { font-size: 20px; }
  .btn-cetak { background: #1a73e8; color: #fff; border: 0; cursor: pointer; }
  .btn-excel { background: #1d6f42; color: #fff; border: 0; cursor: pointer; }
  .btn-tampil { background: #333; color: #fff; border: 0; cursor: pointer; }
  .judul-cetak { display: none; }
  @media print {
    .judul-cetak { display: block; text-align: center; margin-bottom: 10px; }
    body { margin: 0; }
  }
</style>
HTML;
require 'header.php';
?>

<div class="no-print">
    <h1>Filter Laporan Penjualan</h1>
    <form method="GET">
        Dari: <input type="date" name="mulai" value="<?= e($mulai) ?>" required>
        Sampai: <input type="date" name="selesai" value="<?= e($selesai) ?>" required>
        <button type="submit" class="btn-tampil">Tampilkan</button>
    </form>
    <?php if ($tampil && !empty($rekap)): ?>
        <button type="button" class="btn-cetak" onclick="window.print()">Cetak</button>
        <a href="export_excel.php?mulai=<?= urlencode($mulai) ?>&selesai=<?= urlencode($selesai) ?>">
            <button type="button" class="btn-excel">Excel</button>
        </a>
    <?php endif; ?>
    <?php if ($error): ?><p class="err"><?= e($error) ?></p><?php endif; ?>
</div>

<?php if ($tampil && empty($rekap)): ?>
    <p>Tidak ada transaksi pada periode <?= tgl_id($mulai) ?> s/d <?= tgl_id($selesai) ?>.</p>
<?php endif; ?>

<?php if ($tampil && !empty($rekap)): ?>
    <div class="judul-cetak">
        <h1>Laporan Penjualan</h1>
        <p>Periode: <?= tgl_id($mulai) ?> s/d <?= tgl_id($selesai) ?></p>
    </div>

    <h2>Grafik Penjualan</h2>
    <div class="chart-box"><canvas id="myChart"></canvas></div>
    <script>
        const ctx = document.getElementById('myChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($labels) ?>,
                datasets: [{
                    label: 'Total Penjualan',
                    data: <?= json_encode($data_total) ?>,
                    backgroundColor: 'rgba(26, 115, 232, 0.6)',
                    borderColor: 'rgba(26, 115, 232, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false, // agar grafik langsung tampil saat dicetak
                plugins: {
                    tooltip: { callbacks: {
                        label: c => 'Rp ' + Number(c.parsed.y).toLocaleString('id-ID')
                    } }
                },
                scales: {
                    x: { title: { display: true, text: 'Tanggal Transaksi' } },
                    y: {
                        beginAtZero: true,
                        title: { display: true, text: 'Total Pendapatan (Rp)' },
                        ticks: { callback: v => 'Rp ' + Number(v).toLocaleString('id-ID') }
                    }
                }
            }
        });
    </script>

    <h2>Rekapitulasi</h2>
    <table>
        <tr><th>No</th><th>Total Pendapatan</th><th>Tanggal Transaksi</th></tr>
        <?php $no = 1; foreach ($rekap as $row): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td class="kanan"><?= rupiah($row['total_harian']) ?></td>
            <td><?= tgl_id($row['tgl']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <div class="card">
        <div>
            <small>Jumlah Pelanggan Unik</small>
            <strong><?= $total_pelanggan ?> Orang</strong>
        </div>
        <div>
            <small>Total Pendapatan Keseluruhan</small>
            <strong><?= rupiah($total_pendapatan) ?></strong>
        </div>
    </div>
<?php endif; ?>

</body>
</html>
