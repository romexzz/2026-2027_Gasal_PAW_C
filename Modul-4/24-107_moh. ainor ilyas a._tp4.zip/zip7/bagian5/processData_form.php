<?php
$errors = array();

if (isset($_POST['surname'])) {      // form sudah di-submit
    require 'validate.inc';
    validateName($errors, $_POST, 'surname');

    if ($errors) {                   // ada error
        echo '<h1>Invalid, correct the following errors:</h1>';
        foreach ($errors as $field => $error)
            echo "$field $error<br/>";
        // tampilkan kembali form
        include 'form.inc';
    } else {                         // tidak ada error
        echo 'Form submitted successfully with no errors';
    }
} else {
    // tampilkan form kosong
    include 'form.inc';
}
?>
