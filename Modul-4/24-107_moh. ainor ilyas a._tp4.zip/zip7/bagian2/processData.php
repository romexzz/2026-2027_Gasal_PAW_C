<?php
// Menampilkan semua isian form dengan foreach pada array asosiatif
echo "<h2>Data yang Dikirim</h2>";
foreach ($_POST as $field => $value) {
    echo "<p><strong>" . htmlspecialchars($field) . "</strong> : "
       . htmlspecialchars($value) . "</p>";
}
?>
