<?php
$errors = array();

if (isset($_POST['surname'])) {      // form sudah di-submit
    require 'validate.inc';
    validateName($errors, $_POST, 'surname');
    validateEmail($errors, $_POST, 'email');
    validatePassword($errors, $_POST, 'password');
    validateRequired($errors, $_POST, 'address');
    validateState($errors, $_POST, 'state');
    validateGender($errors, $_POST, 'gender');

    if ($errors) {                   // ada error
        echo '<h1>Invalid, correct the following errors:</h1>';
        foreach ($errors as $field => $error)
            echo "$field $error<br/>";
        include 'form.inc';          // form tampil lagi + isian lama
    } else {                         // tidak ada error
        echo 'Form submitted successfully with no errors';
    }
} else {
    include 'form.inc';              // akses pertama: form kosong
}
?>
