PETUNJUK: satu folder = satu bagian di laporan.
Salin satu folder ke htdocs, buka file yang disebut, lalu screenshot hasilnya.


bagian1: buka processData_form.html
   kotak kode di laporan : processData_form.html
bagian2: buka processData_form.html
   kotak kode di laporan : processData.php
   file pendukung (bukan kotak kode): processData_form.html
bagian3: buka processData_form.html
   kotak kode di laporan : validate.inc, processData.php
   file pendukung (bukan kotak kode): processData_form.html
bagian4: buka processData_form.html
   kotak kode di laporan : validate.inc, processData.php
   file pendukung (bukan kotak kode): processData_form.html
bagian5: buka processData_form.php
   kotak kode di laporan : form.inc, processData_form.php
   file pendukung (bukan kotak kode): validate.inc
bagian6: buka processData_form.php
   kotak kode di laporan : form.inc
   file pendukung (bukan kotak kode): validate.inc, processData_form.php
bagian7: buka processData_form.php
   kotak kode di laporan : validate.inc, processData_form.php
   file pendukung (bukan kotak kode): form.inc
