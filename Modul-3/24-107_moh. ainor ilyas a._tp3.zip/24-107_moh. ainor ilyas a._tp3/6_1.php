<?php
function tampil($arr) {
    $hasil = "";
    foreach ($arr as $v) { $hasil .= $v . " "; }
    return trim($hasil);
}
function tampilAsosiatif($arr) {
    $hasil = "";
    foreach ($arr as $k => $v) { $hasil .= $k . "=> " . $v . ", "; }
    return trim($hasil);
}

// array_push()
$a = array("A");
echo 'Array awal: ("A")<br>';
array_push($a, "B");
echo "Hasil array_push: " . tampil($a) . "<br><br>";

// array_merge()
$b = array_merge(array("A", "B"), array("C"));
echo 'Array awal: ("A", "B") digabung dengan ("C")<br>';
echo "Hasil array_merge: " . tampil($b) . "<br><br>";

// array_values()
$c = array("x" => 1, "y" => 2);
echo 'Array awal: ("x" => 1, "y" => 2)<br>';
echo "Hasil array_values: " . tampil(array_values($c)) . "<br><br>";

// array_search()
$d = array("A", "B", "C");
echo 'Mencari "B" pada array: ("A", "B", "C")<br>';
echo "Hasil array_search: " . array_search("B", $d) . "<br><br>";

// array_filter() -> menghapus nilai yang dianggap false (0, false, "")
$e = array(0, 1, false, 2, "", 3, "array");
echo 'Array awal: (0, 1, false, 2, "", 3, "array")<br>';
echo "Hasil array_filter: " . tampil(array_filter($e)) . "<br><br>";

// sort() & rsort() -> array terindeks
$f = array(3, 1, 2);
echo "Array awal: (3, 1, 2)<br>";
sort($f);
echo "Hasil sort: " . tampil($f) . "<br>";
rsort($f);
echo "Hasil rsort: " . tampil($f) . "<br><br>";

// asort(), ksort(), arsort(), krsort() -> array asosiatif
$age = array("Peter" => 35, "Ben" => 37, "Joe" => 43);
echo 'Array awal: ("Peter"=>35, "Ben"=>37, "Joe"=>43)<br>';

$t = $age; asort($t);
echo "Hasil asort: " . tampilAsosiatif($t) . "<br>";
$t = $age; ksort($t);
echo "Hasil ksort: " . tampilAsosiatif($t) . "<br>";
$t = $age; arsort($t);
echo "Hasil arsort: " . tampilAsosiatif($t) . "<br>";
$t = $age; krsort($t);
echo "Hasil krsort: " . tampilAsosiatif($t) . "<br>";
?>