<?php
$height = array("Andy"=>"176", "Barry"=>"165", "Charlie"=>"170");

// Tambah lima data baru
$height["David"]  = "180";
$height["Ethan"]  = "172";
$height["Frank"]  = "168";
$height["George"] = "175";
$height["Harry"]  = "182";

$item = array();
foreach ($height as $k => $v) {
    $item[] = '"' . $k . '"=>"' . $v . '"';
}
echo "height = (" . implode(", ", $item) . ")<br><br>";

// Tampilkan seluruh data dengan perulangan
foreach ($height as $nama => $tinggi) {
    echo $nama . " is " . $tinggi . " cm tall.<br>";
}
?>