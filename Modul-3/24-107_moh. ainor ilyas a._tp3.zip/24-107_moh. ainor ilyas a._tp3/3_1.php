<?php
function tampilArray($nama, $arr) {
    $item = array();
    foreach ($arr as $k => $v) {
        $item[] = '"' . $k . '"=>"' . $v . '"';
    }
    echo $nama . " = (" . implode(", ", $item) . ")<br>";
}

$height = array("Andy"=>"176", "Barry"=>"165", "Charlie"=>"170");

// Tambah lima data baru
$height["David"]  = "180";
$height["Ethan"]  = "172";
$height["Frank"]  = "168";
$height["George"] = "175";
$height["Harry"]  = "182";

tampilArray("height", $height);
echo "Nilai dengan indeks terakhir: " . end($height) . "<br><br>";

// Hapus satu data tertentu
unset($height["Barry"]);

tampilArray("height", $height);
echo "Nilai dengan indeks terakhir setelah dihapus: " . end($height);
?>