<?php
$weight = array("Andy"=>"70", "Barry"=>"65", "Charlie"=>"75");

$item = array();
foreach ($weight as $k => $v) {
    $item[] = '"' . $k . '"=>"' . $v . '"';
}
echo "weight = (" . implode(", ", $item) . ")<br>";

// Data kedua
$values = array_values($weight);
echo "Data kedua: " . $values[1];
?>