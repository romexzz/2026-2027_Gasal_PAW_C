<?php
$fruits = array("Avocado", "Blueberry", "Cherry");

// Tambah lima data baru
array_push($fruits, "Durian", "Elderberry", "Fig", "Grape", "Honeydew");

echo 'fruits = ("' . implode('", "', $fruits) . '")<br>';
echo "Nilai dengan indeks tertinggi: " . $fruits[count($fruits) - 1];

?>