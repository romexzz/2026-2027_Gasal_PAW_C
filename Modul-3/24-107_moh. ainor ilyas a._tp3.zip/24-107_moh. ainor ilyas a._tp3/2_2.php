<?php
// Array baru dengan tiga data
$vegies = array("Carrot", "Broccoli", "Spinach");
$arrlength = count($vegies);

for ($x = 0; $x < $arrlength; $x++) {
    echo $vegies[$x];
    echo "<br>";
}

/*
PENJELASAN:
Cukup memodifikasi skrip yang sudah ada, yaitu mengganti nama array
$fruits menjadi $vegies. Struktur for, count(), dan cara aksesnya sama
karena sama-sama array terindeks, jadi tidak perlu membuat skrip baru.
*/
?>