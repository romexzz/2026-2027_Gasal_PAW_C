<?php
$fruits = array("Avocado", "Blueberry", "Cherry");
array_push($fruits, "Durian", "Elderberry", "Fig", "Grape", "Honeydew");

// Hapus satu data tertentu (Blueberry)
$hapus = "Blueberry";
$key = array_search($hapus, $fruits);
unset($fruits[$key]);
$fruits = array_values($fruits); // susun ulang indeks agar berurutan lagi

echo "Data $hapus dihapus.<br>";
echo 'fruits = ("' . implode('", "', $fruits) . '")<br>';
echo "Nilai dengan indeks tertinggi: " . $fruits[count($fruits) - 1];
?>