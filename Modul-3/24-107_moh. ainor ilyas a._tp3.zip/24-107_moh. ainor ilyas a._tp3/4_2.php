<?php
$weight = array("Andy"=>"70", "Barry"=>"65", "Charlie"=>"75");

$item = array();
foreach ($weight as $k => $v) {
    $item[] = '"' . $k . '"=>"' . $v . '"';
}
echo "weight = (" . implode(", ", $item) . ")<br><br>";

// Perulangan FOR pada array asosiatif: ambil dulu daftar key-nya
$keys = array_keys($weight);
$jumlah = count($keys);

for ($i = 0; $i < $jumlah; $i++) {
    $nama = $keys[$i];
    echo $nama . " is " . $weight[$nama] . " kg.<br>";
}
?>